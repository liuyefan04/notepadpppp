/**
 * SCE_RUST_COMMENTBLOCKDOC
 */
fn main() {
    /// SCE_RUST_COMMENTLINEDOC
    println!("Hello, World!");
}
// SCE_RUST_COMMENTLINE
/*
 * SCE_RUST_COMMENTBLOCK
 */
