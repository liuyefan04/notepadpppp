<!--- This is a generic template and may not be applicable in all cases. -->
<!--- Try to follow it where possible. -->

### Description of the Issue
<!--- Provide a more detailed description to the issue itself -->

### Steps to Reproduce the Issue
<!--- Set of steps to reproduce this issue -->
1. 
2. 
3. 

### Expected Behavior
<!--- What did you expect to happen -->

### Actual Behavior
<!--- What actually happened -->

### Debug Information
<!--- In your Notepad++, click on the "?" menu (found to the right of "Window" in the menu bar) -->
<!--- In the menu that drops down, choose "Debug Info..." -->
<!--- A message box will open detailing specifics about your Notepad++ version, plugins, etc. -->
<!--- CLICK ON THE BLUE LINK with the text "Copy debug info into clipboard" -->
<!--- Do a PASTE HERE -->

<!--- Feel free to include any other info, such as screenshots, etc -->
